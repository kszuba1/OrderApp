INSERT INTO PRODUCT (id, name, price) VALUES (101, 'Laptop', 999.99);
INSERT INTO PRODUCT (id, name, price) VALUES (102, 'Smartphone', 499.99);
INSERT INTO PRODUCT (id, name, price) VALUES (103, 'Tablet', 299.99);
INSERT INTO PRODUCT (id, name, price) VALUES (104, 'Headphones', 149.99);
INSERT INTO PRODUCT (id, name, price) VALUES (105, 'Smartwatch', 199.99);