package com.example.orderservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "DELIVERY")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Delivery {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "courier_name")
  private String courierName;

  @Column(name = "delivery_status")
  @Enumerated(EnumType.STRING)
  private DeliveryStatus deliveryStatus;

  @OneToOne(mappedBy = "delivery")
  @EqualsAndHashCode.Exclude
  @JsonIgnore
  private Order order;

  @Override
  public String toString() {
    return "Delivery{" +
        "id=" + id +
        ", courierName='" + courierName + '\'' +
        ", deliveryStatus=" + deliveryStatus +
        '}';
  }
}
