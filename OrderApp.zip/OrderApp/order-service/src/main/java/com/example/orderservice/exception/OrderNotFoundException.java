package com.example.orderservice.exception;

public class OrderNotFoundException extends RuntimeException {

  private static final String MESSAGE = "Order with id %s does not exist";

  public OrderNotFoundException(Long orderId) {
    super(String.format(MESSAGE, orderId));
  }
}
