package com.example.orderservice.dto;

import com.example.orderservice.model.Delivery;
import java.util.List;
import lombok.Data;

@Data
public class OrderDto {

  private String customerName;
  private List<OrderItemDto> orderItems;
  private Delivery delivery;
}
