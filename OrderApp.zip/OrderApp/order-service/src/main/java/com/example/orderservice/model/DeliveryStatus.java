package com.example.orderservice.model;

public enum DeliveryStatus {
  CREATED, PICKED_UP, DELIVERED
}
