package com.example.orderservice.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "'ORDER'")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "customer_name")
  private String customerName;

  @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
  @EqualsAndHashCode.Exclude
  private Set<OrderItem> orderItems;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "delivery_id", referencedColumnName = "id")
  private Delivery delivery;

  @Override
  public String toString() {
    return "Order{" +
        "id=" + id +
        ", customerName='" + customerName + '\'' +
        ", orderItems=" + orderItems +
        ", delivery=" + delivery +
        '}';
  }
}
