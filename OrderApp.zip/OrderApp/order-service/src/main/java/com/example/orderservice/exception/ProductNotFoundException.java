package com.example.orderservice.exception;

public class ProductNotFoundException extends RuntimeException {

  private static final String MESSAGE = "Product with id %s does not exist";

  public ProductNotFoundException(Long productId) {
    super(String.format(MESSAGE, productId));
  }
}
