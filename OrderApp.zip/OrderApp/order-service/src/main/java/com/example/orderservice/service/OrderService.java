package com.example.orderservice.service;

import com.example.orderservice.dto.OrderDto;
import com.example.orderservice.dto.OrderItemDto;
import com.example.orderservice.exception.OrderNotFoundException;
import com.example.orderservice.exception.ProductNotFoundException;
import com.example.orderservice.model.Delivery;
import com.example.orderservice.model.DeliveryStatus;
import com.example.orderservice.model.Order;
import com.example.orderservice.model.OrderItem;
import com.example.orderservice.repository.OrderRepository;
import com.example.orderservice.repository.ProductRepository;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderService {

  private final OrderRepository orderRepository;
  private final ProductRepository productRepository;

  public Order createOrder(OrderDto orderDto) {
    Order order = convertToEntity(orderDto);

    return orderRepository.save(order);
  }

  public void updateDeliveryStatus(Long orderId, DeliveryStatus status) {
    Order order = orderRepository.findById(orderId).orElseThrow(() -> new OrderNotFoundException(orderId));
    order.getDelivery().setDeliveryStatus(status);
    orderRepository.save(order);
  }

  public Order convertToEntity(OrderDto orderDto) {
    Order order = new Order();
    order.setCustomerName(orderDto.getCustomerName());

    if (orderDto.getOrderItems() != null) {
      Set<OrderItem> orderItems = orderDto.getOrderItems().stream()
          .map(this::convertToEntity)
          .collect(Collectors.toSet());
      orderItems.forEach(item -> item.setOrder(order));
      order.setOrderItems(orderItems);
    }

    if (orderDto.getDelivery() != null) {
      Delivery delivery = new Delivery();
      delivery.setCourierName(orderDto.getDelivery().getCourierName());
      delivery.setDeliveryStatus(orderDto.getDelivery().getDeliveryStatus());
      delivery.setOrder(order);
      order.setDelivery(delivery);
    }

    return order;
  }

  private OrderItem convertToEntity(OrderItemDto dto) {
    OrderItem orderItem = new OrderItem();
    orderItem.setProduct(productRepository.findById(dto.getProductId()).orElseThrow(() -> new ProductNotFoundException(dto.getProductId())));
    orderItem.setQuantity(dto.getQuantity());
    return orderItem;
  }
}
