package com.example.orderhistoryservice.controller;

import com.example.orderhistoryservice.exception.OrderHistoryNotFoundException;
import com.example.orderhistoryservice.model.DeliveryStatus;
import com.example.orderhistoryservice.model.OrderHistory;
import com.example.orderhistoryservice.service.OrderHistoryService;
import io.swagger.v3.oas.annotations.Operation;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orders-history")
@RequiredArgsConstructor
public class OrderHistoryController {

  private final OrderHistoryService orderHistoryService;

  @GetMapping
  public List<OrderHistory> getAll() {
    return orderHistoryService.findAll();
  }

  @GetMapping("/{id}")
  public ResponseEntity<OrderHistory> getById(@PathVariable Long id) {
    try {
      return ResponseEntity.ok(orderHistoryService.findById(id));
    } catch (OrderHistoryNotFoundException ex) {
      return ResponseEntity.notFound().build();
    }
  }

  @PostMapping
  public OrderHistory createOrderHistory(@RequestBody OrderHistory orderHistory) {
    return orderHistoryService.createOrderHistory(orderHistory);
  }

  @PutMapping("/{id}/delivery/{status}")
  public ResponseEntity<Void> updateDeliveryStatus(@PathVariable Long id, @PathVariable DeliveryStatus status) {
    try {
      orderHistoryService.updateDeliveryStatus(id, status);
      return ResponseEntity.ok().build();
    }
    catch (OrderHistoryNotFoundException e) {
      return ResponseEntity.notFound().build();
    }
  }
}
