package com.example.orderhistoryservice.configuration;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@Configuration
public class SwaggerConfig {

  @Bean
  public GroupedOpenApi orderHistoryApi() {
    return GroupedOpenApi.builder()
        .group("OrderHistory")
        .pathsToMatch("/api/orders-history/**")
        .addOperationCustomizer((operation, handlerMethod) ->
            handlerMethod.getMethod().getAnnotation(GetMapping.class) != null
            ? operation
            : null)
        .build();
  }

  @Bean
  public GroupedOpenApi syncApi() {
    return GroupedOpenApi.builder()
        .group("Sync")
        .pathsToMatch("/api/orders-history/**")
        .addOperationCustomizer((operation, handlerMethod) -> {
          boolean isPost = handlerMethod.getMethod().getAnnotation(PostMapping.class) != null;
          boolean isPut = handlerMethod.getMethod().getAnnotation(PutMapping.class) != null;
          return isPost || isPut ? operation : null;
        })
        .build();
  }
}
