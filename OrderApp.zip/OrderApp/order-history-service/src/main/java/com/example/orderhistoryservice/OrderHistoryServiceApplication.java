package com.example.orderhistoryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderHistoryServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(OrderHistoryServiceApplication.class, args);
  }

}
