package com.example.orderhistoryservice.repository;

import com.example.orderhistoryservice.model.OrderHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderHistoryRepository extends JpaRepository<OrderHistory, Long> {

}
