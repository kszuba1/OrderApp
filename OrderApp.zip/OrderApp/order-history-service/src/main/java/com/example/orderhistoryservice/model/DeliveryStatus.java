package com.example.orderhistoryservice.model;

public enum DeliveryStatus {
  CREATED, PICKED_UP, DELIVERED
}
