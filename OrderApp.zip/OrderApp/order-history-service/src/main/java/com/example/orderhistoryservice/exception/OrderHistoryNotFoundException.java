package com.example.orderhistoryservice.exception;

public class OrderHistoryNotFoundException extends RuntimeException {

  private static final String MESSAGE = "OrderHistory with id %s does not exist";

  public OrderHistoryNotFoundException(Long id) {
    super(String.format(MESSAGE, id));
  }
}
