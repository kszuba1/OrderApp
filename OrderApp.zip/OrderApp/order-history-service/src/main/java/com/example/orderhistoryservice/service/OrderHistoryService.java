package com.example.orderhistoryservice.service;

import com.example.orderhistoryservice.exception.OrderHistoryNotFoundException;
import com.example.orderhistoryservice.model.DeliveryStatus;
import com.example.orderhistoryservice.model.OrderHistory;
import com.example.orderhistoryservice.repository.OrderHistoryRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderHistoryService {

  private final OrderHistoryRepository orderHistoryRepository;

  public List<OrderHistory> findAll() {
    return orderHistoryRepository.findAll();
  }

  public OrderHistory findById(Long id) {
    return orderHistoryRepository.findById(id).orElseThrow(() -> new OrderHistoryNotFoundException(id));
  }

  public OrderHistory createOrderHistory(OrderHistory orderHistory) {
    return orderHistoryRepository.save(orderHistory);
  }

  public void updateDeliveryStatus(Long id, DeliveryStatus status) {
    OrderHistory orderHistory = findById(id);
    orderHistory.setDeliveryStatus(status);
    orderHistoryRepository.save(orderHistory);
  }

}
